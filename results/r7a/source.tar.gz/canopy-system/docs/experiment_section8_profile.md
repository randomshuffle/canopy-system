# Section 8 prover phase profiles

The profiling build adds exclusive timers to the same `ifold`, `iacc`, and
rate-1/2 and rate-1/4 Merkle reductions described in
[the Section 8 experiment](experiment_section8.md). It measures where prover
time is spent while preserving the protocol, selected-height objective, and
proof/hash accounting.

The corrected workload is `steady_state_v2`: `ifold` takes `ell_cast` fresh
MLE Canopy claims plus one prior compact Batch Canopy claim, returning
`ell_cast + 1` Merkle residual claims. `iacc` combines every residual with
`ell_acc` prior Merkle claims. Its source count is therefore
`ell_cast + 1 + ell_acc`, while each regular Merkle control still takes
`ell_cast + ell_acc` full-length claims. Timing repetitions prepare a valid
representative prior Canopy claim outside the reduction timer. Protocol tests
separately reuse both actual previous accumulator outputs across three steps.

The reduction decomposition has eighteen exclusive components: functional
materialization; four sumcheck phases; message and cached-codeword combinations;
seven output-commitment phases; authentication and returned-claim construction;
the final proof copy; and remaining prover work. Sumcheck, combination, output
commitment, and opening totals are parent measurements. Their exclusive children
sum to them, and the exclusive reduction entries sum to `step_seconds`. Add
parent totals or their children when comparing costs; adding both double counts.

Output commitment separates RS encoding, Merkle leaves, Merkle parents,
digest-to-field conversion, Canopy-layer OOD evaluation, output-polynomial OOD
evaluation, and remaining commitment work. Leaf time includes allocation,
canonical field serialization, and native `hash_rows` work. Digest-to-field
time measures direct conversion to GF(2^256), with zero cryptographic hashes.
`serialization_seconds` measures
only the final `p.proof()` copy, so it does not include all serialization work
performed during the reduction.

`sumcheck_transcript_seconds` includes transcript work plus control and timer
residuals. It is not a measurement of pure hash latency. Dense covector
materialization remains charged to `form_seconds`. The current prover keeps
`Form::Mle` points and equality factors implicit, so fresh MLE sources no longer
allocate or fold dense covectors inside the prover prefix. Carried `Form::Batch` sources and
`Form::Canopy` residuals retain the dense path; sumcheck setup takes ownership
of those buffers. Native per-round allocation shrinking after the first fold is unchanged. The public verifiers still materialize and evaluate
the generic dense forms. Untimed input-claim preparation also materializes
dense forms to compute public sigmas. This changes the prover representation while
preserving the coefficients, challenges, proof structure, queries, and hash
accounting.

Consequently, optimized `ifold` still has nonzero dense materialization for its
prior Batch claim, and `iacc` still materializes the returned Canopy forms and
prior Batch claims. A lower form timer does not mean that all public functionals
have become implicit.

The October 21 implementation borrows each input message for the first
sumcheck round and allocates only its first half-length folded witness. Fresh
MLE folding also computes the evaluations needed for the following round's
polynomial during the fold. Dense carried claims retain the native fold path.
Consequently the polynomial and fold timers move work between them; their sum
is the useful comparison across implementations.

For at least eight sources and a codeword of at least 65,536 field elements,
the prover combines cached codewords in 512-row tiles and hashes each completed
tile immediately. `codeword_leaf_fused=true` identifies this path in raw rows.
Its entire elapsed time is charged to `codeword_combination_seconds`, and
`merkle_leaf_seconds` excludes those output leaves. The encoded Canopy layer
still has separately timed leaves; `iacc` and regular Merkle output leaf timers
are zero on the fused path. Compare the sum of those
two columns with earlier runs; a zero separate leaf timer does not mean hashing
was eliminated. Fresh commitment leaves still have their own timer.

Output encoding is zero for the Merkle controls and `iacc`: they combine cached
input codewords and build a fresh Merkle commitment to the result. `ifold`
additionally encodes its Canopy layer. Encoding fresh inputs remains part of
incoming commitment preparation and is reported in a separate six-component
decomposition. Those components are incoming RS encoding, leaf hashing, parent
hashing, digest-to-field conversion, OOD evaluation, and remaining preparation
work. They sum to `incoming_commit_seconds` and are excluded from reduction time.

Commitment-inclusive totals add only the commitment cost of the `ell_cast`
fresh input oracles. Canopy totals are fresh Canopy commitments plus `ifold`
plus `iacc`; regular Merkle totals are fresh Merkle commitments plus their
batching reduction. Prior Canopy and Merkle commitments are already available
to the accumulation step, so independently preparing representative priors is
excluded from the total. `iacc` has zero fresh commitment sources and reuses
the committed Canopy layers passed from `ifold`.

Raw rows record `fresh_commit_sources`, `fresh_commit_seconds`, and
`prior_commit_seconds`. Six additional exclusive fields record fresh encoding,
leaves, parents, digest conversion, OOD evaluation, and remaining work. The
reporter checks that they sum to the fresh commitment time and that fresh plus
prior equals incoming time. It forms each
`total_prover_seconds = fresh_commit_seconds + step_seconds` before pairing
or computing statistics. These extra times overlap the all-input incoming
decomposition; they are not additional reduction phases. Fresh-phase
percentages divide by fresh commitment time. `percentage_denominator` in the
summary records the denominator used for every component.

The reporter rejects negative/nonfinite phases, unverified samples, duplicate
sample identities, wrong source counts, mixed workload versions, and failures
to reconcile phase sums. It groups by original
message length, `ell_cast`, `ell_acc`, height, row width, security budget, and
scheme. Means, medians, minima, and maxima are retained. Percentages divide a
component mean by its corresponding total mean. Paired `ifold + iacc` totals
sum matching repetition/input-seed samples before computing statistics.
The workload and source count are retained in the summary. Missing CSV workload
tags identify `legacy_fresh_only_v1`, whose `ifold` omits the prior Canopy.
Historical and corrected CSVs cannot be combined in one report.
Complete fresh-cost columns are optional when reading historical files. A
partial bundle or a mixture of files with and without these columns fails the
phase report; no fresh-only cost is inferred from an old all-input incoming
time. Provenance labels the expanded accounting
`cost_scope=fresh_commit_plus_reduction_v1` and older phase-only samples
`cost_scope=reduction_only_v1`.

The earlier shared allocation changes apply across the reductions:
already materialized dense covectors move by ownership into sumcheck setup;
the first unit-weight
RLC coefficient copies its input rather than multiplying every element by one;
`Form::Canopy` covector materialization consumes its equality buffer with
`into_vec` rather than cloning it; and
the Batch public covector's query term is accumulated in place. These changes
preserve the protocol, queries, and proof structure. The earlier profiling
campaign remains a separate artifact.

The equality-buffer change applies only when `Form::Canopy` is materialized;
it does not change Canopy-layer encoding. Fresh `ifold` inputs use MLE
claims, and the prior Canopy input uses `Form::Batch`; their measured
materialization or layer-construction time should not be attributed to that
copy removal.

The [ifold performance audit](../results/section8_ifold_audit_20261008/README.md)
preserves an unchanged dense-prover baseline and an isolated comparison of
dense native, dense keep-capacity, and implicit fresh-MLE kernels. The current
implicit path evaluates the actual message halves and updates an equality
factor without division; it does not infer coefficients from a claimed sigma.
It applies to fresh sources in both Canopy and the regular Merkle controls.
The isolated kernel excludes commitments, carried Batch claims, Fiat–Shamir,
RLC, and verification. Its measured differences cannot be inserted into
complete IR totals. The full baseline/optimized comparison and its build/test
receipts are recorded separately in that audit. Truncate-only folding is not
part of the production change.

Run each configuration and scheme in a fresh process. The runner launches
children sequentially, records their executable/source identities and resource
usage, and refuses an existing output directory. A Canopy child executes both
`ifold` and `iacc`; each child performs one warmup and two measured repetitions.
The full grid has twelve workloads and thirty-six child jobs. Keep the binary
and measured sources fixed while the campaign runs. The runner captures both
reporters and the workload validator in its source snapshot. It accepts only
the corrected workload tag, source counts, and complete fresh-cost columns,
recording their formulas and the commitment-inclusive cost boundary in
`campaign.json`. Use a fresh directory for this workload.

```sh
cargo build --offline --release --example accumulation_section8

python3 scripts/profile_section8_campaign.py \
  --binary target/release/examples/accumulation_section8 \
  --output-dir results/section8_fresh_commit_local/profile \
  --logs 18,20,22 --ell-cast 1,2,4,8 --ell-acc 1 \
  --log-leaf-width 3 --security-bits 128 --objective total \
  --threads 8 --warmups 1 --repetitions 2
```

Once the campaign completes, generate the main report. Use a new output path
for a reproduction if the recorded campaign already exists.

```sh
python3 scripts/report_section8_profile.py \
  --timings results/section8_fresh_commit_local/profile/profiles.csv \
  --provenance results/section8_fresh_commit_local/profile/campaign.json \
    results/section8_fresh_commit_local/build_provenance.json \
  --output-dir results/section8_fresh_commit_local/phases --plot off
```

The report writes `summary.csv`, `README.md`, and `provenance.json`, preserving
the raw source files and their SHA-256 checksums. With Matplotlib available it
also writes `phase_profiles.svg`, stacking the seven coarse exclusive groups
for the four reductions. The Markdown tables show the finer decomposition and
the separate incoming costs. `--plot off` produces the full CSV and Markdown
report without a plotting dependency. Hardware attribution comes only from
supplied provenance. Include `build_provenance.json` only after recording a
matching build; the runner's source snapshot alone does not establish which
sources produced an existing binary.

The [fresh-commitment reference campaign](../results/section8_fresh_commit_20261008/README.md)
covers `N = 2^20` and all four fresh arities. Its
[phase report](../results/section8_fresh_commit_20261008/phases/README.md)
contains 32 verified measured samples and 780 grouped components, including
the fresh commitment phases and commitment-inclusive totals. Fresh/prior
splitting changes the accounting boundary while preserving the protocol and
expected proof/hash model.
That campaign predates the implicit fresh-MLE representation and retains its
original dense-prover executable and measurements.

The earlier [corrected reduction-only campaign](../results/section8_steady_state_20261008/README.md)
covers `N = 2^20` and fresh arities 1, 2, 4, and 8. Its
[phase report](../results/section8_steady_state_20261008/phases/README.md)
contains 32 verified measured samples and 600 grouped phase entries. Heights
5, 5, 4, and 4 are optimized separately for these configurations, and remain
fixed across recurrence steps within a configuration. Changing a live
accumulator's height would require an additional conversion outside this
benchmark.
Those samples predate the fresh/prior commitment split. Their incoming
decomposition includes representative prior preparation; it cannot be added
to reduction time to recover the fresh-only total.

## Historical profiles

The October 7 main campaign and its pre-optimization snapshot both use
`legacy_fresh_only_v1`. Their `ifold` has `ell_cast` inputs and their `iacc`
has `ell_cast + ell_acc`; neither carries the prior Canopy accumulator. They
are preserved unchanged under `results/section8_profile_20261007` and
`results/section8_profile_20261007_before_optimizations`. Their reported
timings, source counts, and selected heights do not describe the corrected
steady-state recurrence. The example below regenerates only a separate
historical report; it does not convert the underlying data to the new workload.

The pre-optimization snapshot covers only `N = 2^22`, `ell_cast = 1`,
`ell_acc = 1`, with the same warmup/repetition and worker counts. Its raw
samples and campaign provenance are preserved under
`results/section8_profile_20261007_before_optimizations`. Generate its separate
report with:

```sh
python3 scripts/report_section8_profile.py \
  --timings results/section8_profile_20261007_before_optimizations/profiles.csv \
  --provenance results/section8_profile_20261007_before_optimizations/campaign.json \
  --output-dir results/section8_profile_20261007_before_optimizations/report_regenerated \
  --plot off
```

The two campaigns have different executable identities. A timing comparison
should use their common workload and retain each campaign's phase attribution;
the older snapshot does not supply measurements for the rest of the grid.

The separate [codeword-kernel diagnostic](../results/section8_codeword_kernel_20261007/README.md)
uses the historical setup and compares cached codeword RLC against encoding
the already combined message once.
It supports the cached rate-1/2 choice in its narrow workload, leaves the
memory-sensitive rate-1/4 winner inconclusive, and finds encoding competitive
for the smaller-message iacc layer. Both outputs stay live, the second kernel
has one extra output allocation, and source trees and sumcheck scratch are
absent. Its two-repetition kernel timings cannot be substituted into complete
IR timings. The main cached-path campaign is preserved.
