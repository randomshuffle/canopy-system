# Final experiment artifacts

The final five-configuration suite, its repeated checks, and the separate
Section 8 accumulation study live here.
Use the [repository reproduction guide](../README.md#reproduce-the-final-suite)
for fresh outputs and the [campaign configurations](../experiments/aws-r5/README.md)
for exact workload, hardware, and timing conventions.

| Directory | Canonical artifact | Scope |
|---|---|---|
| [paper_bcgm_m10](paper_bcgm_m10/README.md) | [proof_sizes_and_hashes.csv](paper_bcgm_m10/proof_sizes_and_hashes.csv) | Current BCGM m=10 proof/hash estimates, all 75 points; no new timings. |
| [bolt_black_box_20261026](bolt_black_box_20261026/README.md) | [summary.csv](bolt_black_box_20261026/summary.csv) | N22, eta=1: matched local comparison of Merkle, current Canopy batching, and separately proved Canopy claims; re-optimized heights, separate commitment/opening times, and proof sizes. |
| [aws_i4i_optimized](aws_i4i_optimized/README.md) | [comparison_iop_rounds_direct_digest.csv](aws_i4i_optimized/comparison_iop_rounds_direct_digest.csv) | Main 70-point measured campaign; hashes corrected for direct digest conversion, original Canopy timings include the removed rehash. |
| [aws_i4i_n30_eta1](aws_i4i_n30_eta1/README.md) | [remote/comparison_iop_rounds.csv](aws_i4i_n30_eta1/remote/comparison_iop_rounds.csv) | Five measured N=2^30, eta=1 points using direct digest conversion. |
| [aws_i4i_bolt_n22_recheck_20260917](aws_i4i_bolt_n22_recheck_20260917/README.md) | [remote/results/summary_iop_rounds.csv](aws_i4i_bolt_n22_recheck_20260917/remote/results/summary_iop_rounds.csv) | Balanced repeated Bolt timings at N=2^22 for eta=1,2,4,8. |
| [aws_i4i_bolt_n24_recheck_20260917](aws_i4i_bolt_n24_recheck_20260917/README.md) | [remote/results/summary_iop_rounds.csv](aws_i4i_bolt_n24_recheck_20260917/remote/results/summary_iop_rounds.csv) | Corresponding repeated Bolt timings at N=2^24. |
| [section8_rbr128_eta_grid_20261026](section8_rbr128_eta_grid_20261026/README.md) | [report/summary.csv](section8_rbr128_eta_grid_20261026/report/summary.csv) | Current 128-bit per-round accumulation comparison, N20 arities 1/2/4/8; retains the arity-1/8 runs and adds 2/4 with the same executable, separate fresh commitment costs, and SNARK-style paper plots. |
| [section8_rbr128_20261026](section8_rbr128_20261026/README.md) | [report/summary.csv](section8_rbr128_20261026/report/summary.csv) | Initial 128-bit per-round campaign, N20 arities 1/8; retained measurements and build/test receipt used by the expanded grid. |
| [section8_optimization_20261021](section8_optimization_20261021/README.md) | [comparison/after.csv](section8_optimization_20261021/comparison/after.csv) | Historical 136-bit local budget. Borrowed/fused sumcheck, allocation-reduced RS, and tiled RLC/leaves; matched N20 arities 1/8, larger timing cases, N20 estimates through arity 64, validation and executable/source receipts. |
| [section8_ifold_audit_20261008](section8_ifold_audit_20261008/README.md) | [comparison/after_report/summary.csv](section8_ifold_audit_20261008/comparison/after_report/summary.csv) | Shared implicit-MLE prover at N=2^20, fresh arities 1/8: interleaved dense/implicit Canopy and both Merkle controls, fresh commitment totals, 32 verified rows and 208 unchanged accounting values. Dense baseline, exact kernel comparison, validation, phase/resource ranges, and timing-noise qualifications retained. |
| [section8_fresh_commit_20261008](section8_fresh_commit_20261008/README.md) | [report/summary.csv](section8_fresh_commit_20261008/report/summary.csv) | Pre-implicit dense-prover reference with corrected recurring state and separately measured fresh commitments: total prover is fresh commit + ifold + iacc, compared with fresh commit + Merkle acc. N=2^20, fresh cast counts 1,2,4,8; one warmup and two measurements. |
| [section8_steady_state_20261008](section8_steady_state_20261008/README.md) | [report/summary.csv](section8_steady_state_20261008/report/summary.csv) | Corrected recurring state: ifold absorbs fresh Canopy claims plus one prior Canopy; iacc absorbs all residuals plus one prior Merkle. N=2^20, fresh cast counts 1,2,4,8; one warmup, two measurements, exclusive profiles. |
| [section8_accumulation_20261007](section8_accumulation_20261007/report/README.md) | [report/summary.csv](section8_accumulation_20261007/report/summary.csv) | Historical workload omitting the previous Canopy claim; separate ifold/iacc costs and Merkle controls at N=2^18,2^20,2^22; cast arities 1,2,4,8; one prior accumulator; one warmup and two local measurements. |
| [section8_profile_20261007](section8_profile_20261007/analysis.md) | [report/summary.csv](section8_profile_20261007/report/summary.csv) | Historical workload omitting the previous Canopy claim; 36-job fresh-process profile with 96 verified rows after shared allocation/combination optimizations; exclusive prover phases, separate incoming costs, and memory/variability qualifications. |
| [section8_profile_20261007_before_optimizations](section8_profile_20261007_before_optimizations/report/README.md) | [report/summary.csv](section8_profile_20261007_before_optimizations/report/summary.csv) | Separate pre-optimization phase snapshot at N=2^22, cast arity 1, one prior accumulator; all four reductions, one warmup, two measured repetitions. |
| [section8_codeword_kernel_20261007](section8_codeword_kernel_20261007/README.md) | [kernels.csv](section8_codeword_kernel_20261007/kernels.csv) | Two-repetition diagnostic of cached RLC versus encoding once for nine-source controls and the iacc layer; output equality checked, memory/order qualified, not full IR timings. |

The current estimate table and historical timing records have separate
provenance. Use the current BCGM table for proof/hash values; the measured
campaigns retain their original parameter and source receipts. Commitment
reporting uses C(N, eta) = eta * C(N, 1); openings are measured at each eta.
For eta > 1 the reported total is derived from these components.

Raw CSVs, logs, validation receipts, source/binary hashes, and original source
bundles remain with each dataset. Bundles and scripts under `remote/` are
original-run snapshots. Old host launchers are in
[archive/launchers](../archive/launchers/README.md); run the current tools under
`scripts/` into fresh output directories. Successful reruns do not rewrite
published measurements.

Exploratory studies and the scheduling audit are indexed separately in
[archive](../archive/README.md). The implementation change to BCGM m=10 did not
rerun historical AWS timings. See each dataset's README for limitations.
