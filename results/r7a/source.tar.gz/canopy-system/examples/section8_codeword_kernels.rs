//! Diagnostic kernels only: cached-codeword RLC versus one native RS encoding.
//! Source preparation, message combination, and exact equality checks are untimed.
use anyhow::{ensure, Result};
use canopy_system::{benchmark_field_element, section8::commitment_config, Fr, FIELD_BYTES};
use clap::Parser;
use rayon::prelude::*;
use serde::Serialize;
use std::{fs::File, hint::black_box, path::PathBuf, time::Instant};
use whir_ref::{
    algebra::ntt::{self, PolynomialSegment, Polynomials},
    buffer::{Buffer, BufferOps},
};

#[derive(Parser)]
#[command(about = "Compare Section 8 codeword construction kernels, not full reductions")]
struct Args {
    #[arg(long, default_value_t = 22)]
    log_message: usize,
    #[arg(long, default_value_t = 9)]
    sources: usize,
    #[arg(long, default_value_t = 2)]
    log_inv_rate: usize,
    #[arg(long, default_value_t = 3)]
    log_leaf_width: usize,
    #[arg(long, default_value_t = 128)]
    security_bits: usize,
    #[arg(long, default_value_t = 8)]
    threads: usize,
    #[arg(long, default_value_t = 1)]
    warmups: usize,
    #[arg(long, default_value_t = 2)]
    repetitions: usize,
    #[arg(long, default_value_t = 91)]
    seed: u64,
    #[arg(long)]
    output: PathBuf,
}

#[derive(Serialize)]
struct Record {
    log_message: usize,
    sources: usize,
    log_inv_rate: usize,
    log_leaf_width: usize,
    security_bits: usize,
    threads: usize,
    seed: u64,
    repetition: usize,
    kernel: &'static str,
    order_index: usize,
    seconds: f64,
    message_combination_seconds: f64,
    source_generation_seconds: f64,
    source_encoding_seconds: f64,
    message_elements: usize,
    codeword_elements: usize,
    cached_message_bytes: usize,
    cached_codeword_bytes: usize,
    output_message_bytes: usize,
    one_output_matrix_bytes: usize,
    verified: bool,
}

// Deliberately mirrors the current shared Section 8 fused Rayon kernel,
// including the first coefficient ONE and single-source clone shortcuts.
fn combine(buffers: &[&Buffer<Fr>], weights: &[Fr], len: usize) -> Buffer<Fr> {
    assert_eq!(weights[0], Fr::ONE);
    if buffers.len() == 1 {
        return (*buffers[0]).clone();
    }
    Buffer::from(
        (0..len)
            .into_par_iter()
            .map(|i| {
                buffers[0].to_slice()[i]
                    + buffers
                        .iter()
                        .zip(weights)
                        .skip(1)
                        .map(|(m, &w)| m.to_slice()[i] * w)
                        .sum::<Fr>()
            })
            .collect::<Vec<_>>(),
    )
}

fn encode(message: &Buffer<Fr>, width: usize, rows: usize) -> Buffer<Fr> {
    let refs = [message];
    let segments = [PolynomialSegment::from_rows(&refs, width)];
    ntt::interleaved_rs_encode(Polynomials::from_segments(&segments), rows)
}

fn main() -> Result<()> {
    let args = Args::parse();
    ensure!(
        args.sources > 0 && args.threads > 0 && args.repetitions > 0,
        "need positive sources, threads and repetitions"
    );
    let passes = args
        .warmups
        .checked_add(args.repetitions)
        .ok_or_else(|| anyhow::anyhow!("pass count overflow"))?;
    ensure!(
        !args.output.exists(),
        "refusing existing output {}",
        args.output.display()
    );
    rayon::ThreadPoolBuilder::new()
        .num_threads(args.threads)
        .build_global()?;
    let cfg = commitment_config(
        args.log_message,
        args.log_inv_rate,
        args.log_leaf_width,
        args.security_bits as f64,
    )?;
    let cached_message_bytes = cfg
        .vector_size()
        .checked_mul(args.sources)
        .and_then(|n| n.checked_mul(FIELD_BYTES))
        .ok_or_else(|| anyhow::anyhow!("input size overflow"))?;
    let cached_codeword_bytes = cfg
        .size()
        .checked_mul(args.sources)
        .and_then(|n| n.checked_mul(FIELD_BYTES))
        .ok_or_else(|| anyhow::anyhow!("codeword size overflow"))?;
    if let Some(parent) = args.output.parent().filter(|p| !p.as_os_str().is_empty()) {
        std::fs::create_dir_all(parent)?;
    }
    let mut output = csv::Writer::from_writer(File::create(&args.output)?);
    eprintln!("Preparing N=2^{} sources={} inverse-rate=2^{} width={} threads={} cached messages={:.3}GiB codewords={:.3}GiB", args.log_message, args.sources, args.log_inv_rate, cfg.interleaving_depth(), rayon::current_num_threads(), cached_message_bytes as f64 / 2f64.powi(30), cached_codeword_bytes as f64 / 2f64.powi(30));
    let t = Instant::now();
    let messages = (0..args.sources)
        .map(|source| {
            Buffer::from(
                (0..cfg.vector_size())
                    .into_par_iter()
                    .map(|i| benchmark_field_element(args.seed, 5000 + source as u64, i as u64))
                    .collect::<Vec<_>>(),
            )
        })
        .collect::<Vec<_>>();
    let generation_seconds = t.elapsed().as_secs_f64();
    let t = Instant::now();
    let matrices = messages
        .iter()
        .map(|message| encode(message, cfg.interleaving_depth(), cfg.codeword_length()))
        .collect::<Vec<_>>();
    let encoding_seconds = t.elapsed().as_secs_f64();
    let message_refs = messages.iter().collect::<Vec<_>>();
    let matrix_refs = matrices.iter().collect::<Vec<_>>();
    for pass in 0..passes {
        let seed = args.seed.wrapping_add(pass as u64);
        let gamma = benchmark_field_element(seed, 9000, 0);
        let mut weight = Fr::ONE;
        let weights = (0..args.sources)
            .map(|_| {
                let old = weight;
                weight *= gamma;
                old
            })
            .collect::<Vec<_>>();
        let t = Instant::now();
        let combined_message = combine(&message_refs, &weights, cfg.vector_size());
        let message_combination_seconds = t.elapsed().as_secs_f64();
        // Measured repetitions alternate which kernel runs first. The other
        // result remains live for the exact equality check after both timers.
        let rlc_first = (pass - args.warmups.min(pass)) % 2 == 1;
        let order = if rlc_first {
            ["cached_rlc", "reencode_once"]
        } else {
            ["reencode_once", "cached_rlc"]
        };
        let mut rlc_result = None;
        let mut encoded_result = None;
        let mut durations = [0.0; 2];
        for (position, kernel) in order.iter().enumerate() {
            let t = Instant::now();
            let matrix = if *kernel == "cached_rlc" {
                combine(black_box(&matrix_refs), black_box(&weights), cfg.size())
            } else {
                encode(
                    black_box(&combined_message),
                    cfg.interleaving_depth(),
                    cfg.codeword_length(),
                )
            };
            black_box(&matrix);
            durations[position] = t.elapsed().as_secs_f64();
            if *kernel == "cached_rlc" {
                rlc_result = Some(matrix);
            } else {
                encoded_result = Some(matrix);
            }
        }
        let rlc_result = rlc_result.unwrap();
        let encoded_result = encoded_result.unwrap();
        ensure!(
            rlc_result.len() == cfg.size() && rlc_result == encoded_result,
            "cached RLC and native encoding differ"
        );
        eprintln!("pass={pass} measured={} order={order:?} durations={durations:?} full-matrix-equality=true", pass >= args.warmups);
        if pass >= args.warmups {
            for (position, kernel) in order.iter().enumerate() {
                output.serialize(Record {
                    log_message: args.log_message,
                    sources: args.sources,
                    log_inv_rate: args.log_inv_rate,
                    log_leaf_width: args.log_leaf_width,
                    security_bits: args.security_bits,
                    threads: rayon::current_num_threads(),
                    seed,
                    repetition: pass - args.warmups,
                    kernel,
                    order_index: position,
                    seconds: durations[position],
                    message_combination_seconds,
                    source_generation_seconds: generation_seconds,
                    source_encoding_seconds: encoding_seconds,
                    message_elements: cfg.vector_size(),
                    codeword_elements: cfg.size(),
                    cached_message_bytes,
                    cached_codeword_bytes,
                    output_message_bytes: cfg.vector_size() * FIELD_BYTES,
                    one_output_matrix_bytes: cfg.size() * FIELD_BYTES,
                    verified: true,
                })?;
            }
            output.flush()?;
        }
    }
    // Keep the exact source-cache footprint live throughout all comparisons.
    black_box((&messages, &matrices));
    Ok(())
}
