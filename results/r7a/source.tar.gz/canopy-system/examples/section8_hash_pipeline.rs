//! Compare exact canonical RLC/hash kernels, including output allocation.
#[path = "../src/section8_codeword.rs"]
mod section8_codeword;
use ark_ff::Field;
use canopy_system::{benchmark_field_element as elem, Fr};
use rayon::prelude::*;
use std::{hint::black_box, time::Instant};
use whir_ref::{
    buffer::{Buffer, BufferOps},
    hash::{self, Hash},
    protocols::matrix_commit,
};
fn main() {
    rayon::ThreadPoolBuilder::new()
        .num_threads(8)
        .build_global()
        .unwrap();
    let args = std::env::args().collect::<Vec<_>>();
    let log_n: usize = args.get(1).map(|s| s.parse().unwrap()).unwrap_or(20);
    let sources: usize = args.get(2).map(|s| s.parse().unwrap()).unwrap_or(9);
    let len = 2usize << log_n;
    let inputs = (0..sources)
        .map(|s| {
            Buffer::from(
                (0..len)
                    .into_par_iter()
                    .map(|i| elem(91, s as u64, i as u64))
                    .collect::<Vec<_>>(),
            )
        })
        .collect::<Vec<_>>();
    let refs = inputs.iter().collect::<Vec<_>>();
    let mut weights = (0..sources)
        .map(|s| elem(91, 123, s as u64))
        .collect::<Vec<_>>();
    weights[0] = Fr::ONE;
    let engine = hash::ENGINES.retrieve(hash::BLAKE3).unwrap();
    let mut expected = None;
    println!("pass,kernel,seconds,equal");
    for pass in 0..3 {
        let mut tiles = vec![0, 128, 256, 512, 1024, 2048];
        if pass % 2 == 1 {
            tiles.reverse();
        }
        for tile in tiles {
            let t = Instant::now();
            let (matrix, hashes) = if tile == 0 {
                let matrix = Buffer::from(
                    (0..len)
                        .into_par_iter()
                        .map(|i| {
                            inputs[0].to_slice()[i]
                                + inputs
                                    .iter()
                                    .zip(&weights)
                                    .skip(1)
                                    .map(|(m, &w)| m.to_slice()[i] * w)
                                    .sum::<Fr>()
                        })
                        .collect::<Vec<_>>(),
                );
                let mut hashes = vec![Hash::default(); len / 8];
                matrix_commit::hash_rows(&*engine, matrix.to_slice(), &mut hashes);
                (matrix, hashes)
            } else {
                section8_codeword::combine_and_hash(&refs, &weights, len / 8, 8, &*engine, tile)
            };
            let elapsed = t.elapsed().as_secs_f64();
            if let Some((ref m, ref h)) = expected {
                assert_eq!(&matrix, m);
                assert_eq!(&hashes, h);
            } else {
                expected = Some((matrix.clone(), hashes.clone()));
            }
            black_box((&matrix, &hashes));
            println!("{pass},{tile},{elapsed},true");
        }
    }
}
