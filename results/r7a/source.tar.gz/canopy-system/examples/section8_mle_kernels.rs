//! Diagnostic fresh-MLE sumcheck kernels; no commitment, carried Batch, or FS work.
//! All variants keep the original source messages and clone folding scratch.
use anyhow::{ensure, Result};
use canopy_system::{benchmark_field_element as elem, Fr, FIELD_BYTES};
use clap::Parser;
use rayon::prelude::*;
use serde::Serialize;
use std::{fs::OpenOptions, hint::black_box, path::PathBuf, time::Instant};
use whir_ref::{
    algebra::{eq_weights, multilinear_extend, sumcheck},
    utils::workload_size,
};

#[derive(Parser)]
#[command(about = "Compare exact fresh-MLE sumcheck kernels, not full reductions")]
struct Args {
    #[arg(long, default_value_t = 20)]
    log_message: usize,
    #[arg(long, default_value_t = 1)]
    sources: usize,
    #[arg(long, default_value_t = 8)]
    threads: usize,
    #[arg(long, default_value_t = 1)]
    warmups: usize,
    #[arg(long, default_value_t = 2)]
    repetitions: usize,
    #[arg(long, default_value_t = 91)]
    seed: u64,
    #[arg(long)]
    output: PathBuf,
}

#[derive(Clone, Copy, Debug)]
enum Kernel {
    DenseNative,
    DenseKeepCapacity,
    ImplicitEq,
}
impl Kernel {
    fn name(self) -> &'static str {
        match self {
            Self::DenseNative => "dense_native",
            Self::DenseKeepCapacity => "dense_keep_capacity",
            Self::ImplicitEq => "implicit_eq",
        }
    }
}

#[derive(Default, Clone, Serialize)]
struct Timings {
    total_seconds: f64,
    form_seconds: f64,
    setup_seconds: f64,
    polynomial_seconds: f64,
    fold_seconds: f64,
    drop_seconds: f64,
    other_seconds: f64,
    initial_message_capacity_elements: usize,
    initial_form_capacity_elements: usize,
    terminal_message_capacity_elements: usize,
    terminal_form_capacity_elements: usize,
    terminal_scratch_capacity_bytes: usize,
    implicit_point_elements: usize,
}

#[derive(Serialize)]
struct Record {
    log_message: usize,
    sources: usize,
    threads: usize,
    seed: u64,
    input_seed: u64,
    repetition: usize,
    kernel: &'static str,
    order_index: usize,
    cached_message_bytes: usize,
    source_generation_seconds: f64,
    trace_bytes: usize,
    trace_blake3: String,
    verified: bool,
    total_seconds: f64,
    form_seconds: f64,
    setup_seconds: f64,
    polynomial_seconds: f64,
    fold_seconds: f64,
    drop_seconds: f64,
    other_seconds: f64,
    initial_message_capacity_elements: usize,
    initial_form_capacity_elements: usize,
    terminal_message_capacity_elements: usize,
    terminal_form_capacity_elements: usize,
    terminal_scratch_capacity_bytes: usize,
    implicit_point_elements: usize,
}

#[derive(Debug, PartialEq, Eq)]
struct Trace {
    // Round-major, then source-major, for stronger checking than an RLC alone.
    source_coefficients: Vec<(Fr, Fr)>,
    combined_coefficients: Vec<(Fr, Fr)>,
    final_values: Vec<Fr>,
    final_form_values: Vec<Fr>,
}
impl Trace {
    fn bytes(&self) -> Vec<u8> {
        let mut out = Vec::new();
        for &(a, c) in &self.source_coefficients {
            out.extend_from_slice(&a.bytes());
            out.extend_from_slice(&c.bytes());
        }
        for &(a, c) in &self.combined_coefficients {
            out.extend_from_slice(&a.bytes());
            out.extend_from_slice(&c.bytes());
        }
        for &value in self.final_values.iter().chain(&self.final_form_values) {
            out.extend_from_slice(&value.bytes());
        }
        out
    }
}

// The power-of-two specialization of native algebra::sumcheck::fold, with
// identical recursive splitting and workload threshold, omitting only shrink.
fn fold_keep_capacity(values: &mut Vec<Fr>, weight: Fr) {
    fn recurse(low: &mut [Fr], high: &[Fr], weight: Fr) {
        if low.len() > workload_size::<Fr>() {
            let mid = low.len() / 2;
            let (ll, lr) = low.split_at_mut(mid);
            let (hl, hr) = high.split_at(mid);
            rayon::join(|| recurse(ll, hl, weight), || recurse(lr, hr, weight));
        } else {
            for (low, high) in low.iter_mut().zip(high) {
                *low += (*high - *low) * weight;
            }
        }
    }
    if values.len() <= 1 {
        return;
    }
    assert!(values.len().is_power_of_two());
    let half = values.len() / 2;
    let (low, high) = values.split_at_mut(half);
    recurse(low, high, weight);
    values.truncate(half);
}

fn run_kernel(
    kernel: Kernel,
    messages: &[Vec<Fr>],
    points: &[Vec<Fr>],
    challenges: &[Fr],
    weights: &[Fr],
) -> (Timings, Trace) {
    assert_eq!(messages.len(), points.len());
    assert_eq!(messages.len(), weights.len());
    assert!(messages.iter().all(|m| m.len() == 1 << challenges.len()));
    assert!(points.iter().all(|p| p.len() == challenges.len()));
    let total = Instant::now();
    let mut times = Timings::default();
    let t = Instant::now();
    let mut forms = match kernel {
        Kernel::DenseNative | Kernel::DenseKeepCapacity => {
            points.iter().map(|p| eq_weights(p)).collect::<Vec<_>>()
        }
        Kernel::ImplicitEq => Vec::new(),
    };
    times.form_seconds = t.elapsed().as_secs_f64();
    let t = Instant::now();
    let mut folded = messages.to_vec();
    let mut eq_scales = vec![Fr::ONE; messages.len()];
    // This metadata is the only covector storage in the implicit variant.
    let implicit_points = match kernel {
        Kernel::ImplicitEq => points.to_vec(),
        _ => Vec::new(),
    };
    times.setup_seconds = t.elapsed().as_secs_f64();
    times.initial_message_capacity_elements = folded.iter().map(Vec::capacity).sum();
    times.initial_form_capacity_elements = forms.iter().map(Vec::capacity).sum();
    times.implicit_point_elements = implicit_points.iter().map(Vec::len).sum();
    let mut trace = Trace {
        source_coefficients: Vec::with_capacity(messages.len() * challenges.len()),
        combined_coefficients: Vec::with_capacity(challenges.len()),
        final_values: Vec::new(),
        final_form_values: Vec::new(),
    };
    for (round, &r) in challenges.iter().enumerate() {
        let t = Instant::now();
        let mut coefficients = Vec::with_capacity(messages.len());
        let mut combined = (Fr::ZERO, Fr::ZERO);
        for source in 0..messages.len() {
            let (a, c) = match kernel {
                Kernel::DenseNative | Kernel::DenseKeepCapacity => {
                    sumcheck::compute_sumcheck_polynomial(&folded[source], &forms[source])
                }
                Kernel::ImplicitEq => {
                    let m = &folded[source];
                    let z = implicit_points[source][round];
                    let tail = &implicit_points[source][round + 1..];
                    let (low, high) = m.split_at(m.len() / 2);
                    // Direct evaluations depend only on the actual witness.
                    // No claimed sigma, inverses, or inferred values are used.
                    let l0 = multilinear_extend(low, tail);
                    let l1 = multilinear_extend(high, tail);
                    let scale = eq_scales[source];
                    // In GF(2^256), 2*z-1 = ONE and subtraction is addition.
                    (scale * (Fr::ONE - z) * l0, scale * (l1 - l0))
                }
            };
            coefficients.push((a, c));
            combined.0 += a * weights[source];
            combined.1 += c * weights[source];
        }
        times.polynomial_seconds += t.elapsed().as_secs_f64();
        trace.source_coefficients.extend(coefficients);
        trace.combined_coefficients.push(combined);
        let t = Instant::now();
        for source in 0..messages.len() {
            match kernel {
                Kernel::DenseNative => {
                    sumcheck::fold(&mut folded[source], r);
                    sumcheck::fold(&mut forms[source], r);
                }
                Kernel::DenseKeepCapacity => {
                    fold_keep_capacity(&mut folded[source], r);
                    fold_keep_capacity(&mut forms[source], r);
                }
                Kernel::ImplicitEq => {
                    sumcheck::fold(&mut folded[source], r);
                    let z = implicit_points[source][round];
                    eq_scales[source] *= Fr::ONE - z - r;
                }
            }
        }
        times.fold_seconds += t.elapsed().as_secs_f64();
    }
    trace.final_values = folded.iter().map(|m| m[0]).collect();
    trace.final_form_values = match kernel {
        Kernel::DenseNative | Kernel::DenseKeepCapacity => forms.iter().map(|f| f[0]).collect(),
        Kernel::ImplicitEq => eq_scales.clone(),
    };
    times.terminal_message_capacity_elements = folded.iter().map(Vec::capacity).sum();
    times.terminal_form_capacity_elements = forms.iter().map(Vec::capacity).sum();
    times.terminal_scratch_capacity_bytes = (times.terminal_message_capacity_elements
        + times.terminal_form_capacity_elements)
        * FIELD_BYTES;
    // Release retained scratch before returning, so equality checks retain only
    // the small traces. In a full prover this release must precede the RLC.
    let t = Instant::now();
    drop((folded, forms, eq_scales, implicit_points));
    times.drop_seconds = t.elapsed().as_secs_f64();
    times.total_seconds = total.elapsed().as_secs_f64();
    times.other_seconds = times.total_seconds
        - times.form_seconds
        - times.setup_seconds
        - times.polynomial_seconds
        - times.fold_seconds
        - times.drop_seconds;
    black_box((&times, &trace));
    (times, trace)
}

fn public_inputs(log: usize, sources: usize, seed: u64) -> (Vec<Vec<Fr>>, Vec<Fr>, Vec<Fr>) {
    let points = (0..sources)
        .map(|s| {
            (0..log)
                .map(|i| elem(seed, 2000 + s as u64, i as u64))
                .collect()
        })
        .collect();
    let challenges = (0..log).map(|i| elem(seed, 3000, i as u64)).collect();
    let beta = elem(seed, 4000, 0);
    let mut power = Fr::ONE;
    let weights = (0..sources)
        .map(|_| {
            let out = power;
            power *= beta;
            out
        })
        .collect();
    (points, challenges, weights)
}

fn main() -> Result<()> {
    let args = Args::parse();
    ensure!(args.log_message <= 26, "log-message must be at most 26");
    ensure!(
        args.sources > 0 && args.threads > 0 && args.repetitions > 0,
        "need positive sources, threads, and repetitions"
    );
    let passes = args
        .warmups
        .checked_add(args.repetitions)
        .ok_or_else(|| anyhow::anyhow!("pass count overflow"))?;
    let cached_message_bytes = (1usize << args.log_message)
        .checked_mul(args.sources)
        .and_then(|n| n.checked_mul(FIELD_BYTES))
        .ok_or_else(|| anyhow::anyhow!("input size overflow"))?;
    ensure!(
        !args.output.exists(),
        "refusing existing output {}",
        args.output.display()
    );
    rayon::ThreadPoolBuilder::new()
        .num_threads(args.threads)
        .build_global()?;
    if let Some(parent) = args.output.parent().filter(|p| !p.as_os_str().is_empty()) {
        std::fs::create_dir_all(parent)?;
    }
    let file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&args.output)?;
    let mut output = csv::Writer::from_writer(file);
    let t = Instant::now();
    let messages = (0..args.sources)
        .map(|s| {
            (0..1usize << args.log_message)
                .into_par_iter()
                .map(|i| elem(args.seed, 1000 + s as u64, i as u64))
                .collect::<Vec<_>>()
        })
        .collect::<Vec<_>>();
    let source_generation_seconds = t.elapsed().as_secs_f64();
    eprintln!("Fresh-only MLE diagnostic: N=2^{} sources={} threads={} cached messages={:.3}MiB; carried Batch, commitments, FS, RLC excluded", args.log_message, args.sources, args.threads, cached_message_bytes as f64 / 2f64.powi(20));
    for pass in 0..passes {
        let input_seed = args.seed.wrapping_add(pass as u64);
        let (points, challenges, weights) =
            public_inputs(args.log_message, args.sources, input_seed);
        let measured = pass >= args.warmups;
        let repetition = pass.saturating_sub(args.warmups);
        let order = if !measured {
            [
                Kernel::DenseKeepCapacity,
                Kernel::ImplicitEq,
                Kernel::DenseNative,
            ]
        } else if repetition % 2 == 0 {
            [
                Kernel::DenseNative,
                Kernel::DenseKeepCapacity,
                Kernel::ImplicitEq,
            ]
        } else {
            [
                Kernel::ImplicitEq,
                Kernel::DenseKeepCapacity,
                Kernel::DenseNative,
            ]
        };
        let mut results = Vec::new();
        for &kernel in &order {
            let (times, trace) =
                run_kernel(kernel, black_box(&messages), &points, &challenges, &weights);
            results.push((kernel, times, trace));
        }
        let expected_bytes = results[0].2.bytes();
        for (_, _, trace) in &results {
            ensure!(
                trace == &results[0].2 && trace.bytes() == expected_bytes,
                "kernel trace mismatch"
            );
        }
        let trace_blake3 = blake3::hash(&expected_bytes).to_hex().to_string();
        eprintln!("pass={pass} measured={measured} order={:?} seconds={:?} every-coefficient-and-terminal-byte-equal=true", order.map(Kernel::name), results.iter().map(|(_,t,_)|t.total_seconds).collect::<Vec<_>>());
        if measured {
            for (order_index, (kernel, timings, _)) in results.into_iter().enumerate() {
                output.serialize(Record {
                    log_message: args.log_message,
                    sources: args.sources,
                    threads: args.threads,
                    seed: args.seed,
                    input_seed,
                    repetition,
                    kernel: kernel.name(),
                    order_index,
                    cached_message_bytes,
                    source_generation_seconds,
                    trace_bytes: expected_bytes.len(),
                    trace_blake3: trace_blake3.clone(),
                    verified: true,
                    total_seconds: timings.total_seconds,
                    form_seconds: timings.form_seconds,
                    setup_seconds: timings.setup_seconds,
                    polynomial_seconds: timings.polynomial_seconds,
                    fold_seconds: timings.fold_seconds,
                    drop_seconds: timings.drop_seconds,
                    other_seconds: timings.other_seconds,
                    initial_message_capacity_elements: timings.initial_message_capacity_elements,
                    initial_form_capacity_elements: timings.initial_form_capacity_elements,
                    terminal_message_capacity_elements: timings.terminal_message_capacity_elements,
                    terminal_form_capacity_elements: timings.terminal_form_capacity_elements,
                    terminal_scratch_capacity_bytes: timings.terminal_scratch_capacity_bytes,
                    implicit_point_elements: timings.implicit_point_elements,
                })?;
            }
            output.flush()?;
        }
    }
    black_box(&messages);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn compare(messages: &[Vec<Fr>], points: &[Vec<Fr>], challenges: &[Fr], weights: &[Fr]) {
        let (_, dense) = run_kernel(Kernel::DenseNative, messages, points, challenges, weights);
        for kernel in [Kernel::DenseKeepCapacity, Kernel::ImplicitEq] {
            let (times, actual) = run_kernel(kernel, messages, points, challenges, weights);
            assert_eq!(actual, dense);
            assert_eq!(actual.bytes(), dense.bytes());
            assert!(times.other_seconds >= 0.0);
            if matches!(kernel, Kernel::DenseKeepCapacity) {
                assert_eq!(
                    times.initial_message_capacity_elements,
                    times.terminal_message_capacity_elements
                );
                assert_eq!(
                    times.initial_form_capacity_elements,
                    times.terminal_form_capacity_elements
                );
            }
        }
    }

    #[test]
    fn exact_mle_coefficients_for_random_and_zero_one_coordinates() {
        for log in 0..=6 {
            for seed in 0..4 {
                let messages = (0..3)
                    .map(|s| {
                        (0..1usize << log)
                            .map(|i| elem(seed, s, i as u64))
                            .collect()
                    })
                    .collect::<Vec<Vec<_>>>();
                let (points, challenges, weights) = public_inputs(log, 3, seed);
                compare(&messages, &points, &challenges, &weights);
                let mut edge_points = points.clone();
                for point in &mut edge_points {
                    for (i, z) in point.iter_mut().enumerate() {
                        *z = if i % 2 == 0 { Fr::ZERO } else { Fr::ONE };
                    }
                }
                let edge_challenges = (0..log)
                    .map(|i| if i % 2 == 0 { Fr::ONE } else { Fr::ZERO })
                    .collect::<Vec<_>>();
                compare(&messages, &edge_points, &edge_challenges, &weights);
                if log > 0 {
                    let mut zero_factor_challenges = challenges.clone();
                    zero_factor_challenges[0] = Fr::ONE - points[0][0];
                    compare(&messages, &points, &zero_factor_challenges, &weights);
                }
            }
        }
    }

    #[test]
    fn retained_fold_matches_native_around_parallel_threshold() {
        for threads in [1, 2, 8] {
            rayon::ThreadPoolBuilder::new()
                .num_threads(threads)
                .build()
                .unwrap()
                .install(|| {
                    for n in [0, 1, 2, 4, 4096, 8192, 16384] {
                        for r in [Fr::ZERO, Fr::ONE, elem(91, 5000, 0)] {
                            let original =
                                (0..n).map(|i| elem(91, 6000, i as u64)).collect::<Vec<_>>();
                            let mut native = original.clone();
                            let mut retained = original;
                            sumcheck::fold(&mut native, r);
                            fold_keep_capacity(&mut retained, r);
                            assert_eq!(retained, native);
                        }
                    }
                });
        }
    }
}
