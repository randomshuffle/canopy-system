# October 28 rerun on r7a.32xlarge

This campaign retains all three original WHIR configurations, includes the
unchanged shared Merkle Bolt baseline, replaces the white-box Bolt Canopy
method with the black-box construction, and adds steady-state Section 8
accumulation with its two Merkle controls. The manuscript is not edited by
the runner. Prior benchmark evidence remains unchanged.

## Fixed grid and timing policy

- SNARK grid: N=2^22,2^24,2^26 with eta=1,2,4,8; N=2^28 with eta=1,2;
  N=2^30 with eta=1. Five methods at every point.
- Accumulation: N=2^20, ell_cast=1,2,4,8, ell_acc=1. Three methods: paired
  ifold+iacc and ordinary Merkle batching at rates 1/2 and 1/4.
- Both 1 and 32 Rayon threads, with CPU affinity [0] and [0..31]. These are
  physical cores on NUMA node 0 of the AMD EPYC 9R14 host. Default first-touch
  memory placement is retained; no interleaving or explicit memory binding.
- One warmup, two measured repetitions. Each job runs alone, including both
  thread configurations. Pilots are retained samples, not additional runs.
- 84 sequential timing jobs produce 174 method points: 150 SNARK and 24
  accumulation. Each paired Canopy point retains both reduction rows.
- Native Rust 1.92.0, locked dependencies, `-C target-cpu=native`, 32 build jobs.
  No FS instrumentation in timed executables. Instrumented tests use a
  separate target directory. PCLMUL field arithmetic is checked on the host.
- 800 GiB process address-space limit, 64 GiB minimum available host memory,
  no swap. A failure stops the driver and preserves evidence for inspection.

WHIR keeps its component-composed timing harness, including shared measured
base RS encoding and native component verification. Its proof model optimizes
folds in {3,4}, whereas the established timing harness uses fold log 3 and
Canopy height 4. WHIR and Bolt retain the 136-bit local budget. Accumulation
retains the 128-bit round-by-round target and Johnson slack 1.05.

Black-box Bolt uses Canopy only for input X/Y commitments. Every subsequent
Bolt IOPP oracle uses Merkle. Canopy SEP obligations are proved separately
from Bolt's claims, batching within each X or Y family across inputs. Each
Canopy codeword has N/16 field elements. X/Y heights are independently
optimized for expected proof bytes, including full-height constant layers.
The unchanged Bolt shared IOPP joins at k/8, k=N/4. Height searches and 100
proof-size sampling trials are hardware independent and shared by both thread
configurations. Verifier counts include authentication and FS finalizations;
digest-to-field conversion adds zero hashes.

The accumulation height minimizes combined ifold+iacc verifier hashes, with
a Canopy codeword half the input codeword length. Eight fields per leaf are
retained. The measured step has ell_cast+1 Canopy sources for ifold and
ell_cast+2 Merkle sources for iacc; the two returned accumulator claims are
retained. Initial commitment cost covers only fresh inputs. Prior commitments,
input generation, verification, and the final membership decider are excluded
from the accumulation prover total. The Merkle controls batch ell_cast+1
claims in their original code. Every measured reduction is verified.

Raw SNARK commitments are retained. The comparison table additionally uses
the existing sequential IOP-round policy C(N,eta)=eta*C(N,1), using the mean
eta=1 timing for the same method and thread count. Openings are measured at
the requested eta. These derived totals are explicitly labeled and are not
independent whole-protocol measurements. Accumulation reports the measured
fresh commitment cost directly, separately from ifold+iacc or baseline acc.

## Execution and retained evidence

Remote checkout: `/home/ubuntu/canopy-rerun-20261028/canopy-system`.
Local/remote result directory: `results/aws_r7a_20261028`.

```sh
python3 scripts/aws_rerun.py plan
python3 scripts/aws_rerun.py run
python3 scripts/aws_rerun.py report
```

The driver has a process lock, atomic status updates, per-job logs and resource
receipts, frozen source/binary hashes, a host inventory, complete height
searches, separate raw samples/profiles, comparison tables and thread-speedup
tables. Only complete jobs with identical fingerprints may be resumed.
Incomplete jobs require inspection; the driver does not overwrite them.
The three WHIR proof/hash estimates and Bolt baseline are checked against the
retained paper data before starting measurements.

`status.json` reports the active job, Rayon threads, elapsed time, RSS and
completed method points. The five-minute thread heartbeat reads that status.
The instance is left running when the campaign finishes.
